$(document).ready(function(){
  $('ul.tabs').tabs();
});
